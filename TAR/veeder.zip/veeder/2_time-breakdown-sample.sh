#!/bin/bash
INPUT_DIR=/user/admin/sql_benchmark_data/raw_data_full
OUTPUT_DIR=/user/admin/sql_benchmark_data/with_time_full

APP_JAR=com.techresearch.sqlbenchmark.dataprocessor-1.3-jar-with-dependencies.jar
NUM_EXECUTORS=100
EXECUTOR_MEM=30G

spark-submit --class com.techResearch.BreakdownTime \
 --master yarn-client \
--num-executors $NUM_EXECUTORS \
--driver-memory 2G --executor-memory $EXECUTOR_MEM \
$APP_JAR \
$INPUT_DIR/SMS/* $OUTPUT_DIR/SMSEvent/ 0 1

spark-submit --class com.techResearch.BreakdownTime \
 --master yarn-client \
--num-executors $NUM_EXECUTORS \
--driver-memory 2G --executor-memory $EXECUTOR_MEM \
$APP_JAR \
$INPUT_DIR/Topup/* $OUTPUT_DIR/TopupEvent/ 0 1
