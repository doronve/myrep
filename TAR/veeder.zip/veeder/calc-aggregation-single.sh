#!/bin/bash

APP_JAR=com.techresearch.sqlbenchmark.dataprocessor-1.3-jar-with-dependencies.jar
MASTER=yarn-cluster

EXECUTOR_MEM=15G
NUM_EXECUTORS=128
DRIVER_MEM=1G
EXECUTOR_CORES=2

OUTPUT_DIR=$1
INPUT_DIR=$2
CLASS=$3
NUM_LOAD_PARTITIONS=358
NUM_REDUCE_PARTITIONS=1000

export YARN_CONF_DIR=/etc/hadoop/conf.cloudera.yarn/
export HADOOP_CONF_DIR=/etc/hadoop/conf/

echo starting job: $CLASS
spark-submit --class $CLASS \
--master $MASTER \
--num-executors $NUM_EXECUTORS \
--driver-memory $DRIVER_MEM --executor-memory $EXECUTOR_MEM \
--executor-cores $EXECUTOR_CORES \
$APP_JAR \
$INPUT_DIR/ $OUTPUT_DIR/ $NUM_LOAD_PARTITIONS $NUM_REDUCE_PARTITIONS
