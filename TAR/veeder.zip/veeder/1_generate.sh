#!/bin/bash

OUTPUT_FOLDER=/DFS_MOUNT/user/admin/sql_benchmark_data/raw_data_full

#rm -f -r $OUTPUT_FOLDER

rm -f log

nohup java -cp amdocs.sql.datagenerator-1.2-SNAPSHOT-jar-with-dependencies.jar:\
/etc/hadoop/conf.cloudera.yarn/:/etc/hadoop/conf.cloudera.hdfs/:/etc/hadoop/conf \
Entry resourceManagerAddress=h85.amdocs.com:8032 zookeeperNodes=10.232.83.162:2181,10.232.83.85:2181,10.232.83.86:2181 instanceCount=200 subscribers=1000000 cycles=140 outputFolder=$OUTPUT_FOLDER 2>&1 > log &

echo $!