#!/bin/bash

OUTPUT_DIR=/user/admin/sql_benchmark_data/aggregated_full

SMS_CLASSES="com.techResearch.sms.SMSPhonebookCalc \
com.techResearch.sms.SMSCountPerHourCalc \
com.techResearch.sms.SMSAggregateCalc \
com.techResearch.sms.BytesPerHourCalc"


for CLASS in $SMS_CLASSES
do
    ./calc-aggregation-single.sh $OUTPUT_DIR "/user/admin/sql_benchmark_data/with_time_full/SMSEvent" $CLASS
    echo task: $CLASS completed
done

TOPUP_CLASSES="com.techResearch.topups.TopupPointCountCalc \
com.techResearch.topups.TopupInfoPerHourCalc \
com.techResearch.topups.TopupAggregateCalc \
com.techResearch.topups.ProtocolCountCalc \
com.techResearch.topups.PlaceCalc \
com.techResearch.topups.OperationCountCalc \
com.techResearch.topups.ErrorCodeCountCalc \
com.techResearch.topups.CurrencyAmountCalc \
com.techResearch.topups.AuthorizationCalc"

for CLASS in $SMS_CLASSES
do
    ./calc-aggregation-single.sh $OUTPUT_DIR "/user/admin/sql_benchmark_data/with_time_full/TopupEvent" $CLASS
    echo task: $CLASS completed
done
